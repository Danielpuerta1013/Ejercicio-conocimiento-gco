package com.example.formularioProveedores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormularioProveedoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormularioProveedoresApplication.class, args);
	}

}
