package com.example.formularioProveedores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormularioProveedoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
